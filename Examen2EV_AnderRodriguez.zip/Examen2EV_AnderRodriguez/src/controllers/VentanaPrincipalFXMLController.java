package controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import config.ConexionDB;
import dao.EmailDAO;
import dao.PersonaDAO;
import dao.TelefonoDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.scene.control.MenuItem;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Label;

import javafx.scene.control.ListView;

import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.Email;
import model.Persona;
import model.Telefono;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class VentanaPrincipalFXMLController implements Initializable {
	@FXML
	private MenuItem menuInforme1;
	@FXML
	private MenuItem menuInforme2;
	@FXML
	private MenuItem menuAyuda;
	@FXML
	private MenuItem menuAyudaOnline;
	@FXML
	private Label lblTitulo;
	@FXML
	private ListView<Telefono> lstTelefonos;
	@FXML
	private Button btnNuevoTlf;
	@FXML
	private Button btnBorrarTlf;
	@FXML
	private ListView<Email> lstEmails;
	@FXML
	private Button btnNuevoEmail;
	@FXML
	private Button btnBorrarEmail;
	@FXML
	private Button btnAnterior;
	@FXML
	private Button btnSiguiente;
	@FXML
	private Label lblNumPersona;

	private ArrayList<Persona> arrPersonas;

	private PersonaDAO cPersona;
	private Persona p;

	private TelefonoDAO cTelefono;
	private Telefono t;

	private EmailDAO cEmail;
	private Email e;

	private ObservableList<Email> dataEmail;
	private int iLstEmail = -1;

	private ObservableList<Telefono> dataTelefono;
	private int iLstTelefono = -1;

	private int lenPersonas, iPersonas = 0;

	// Event Listener on MenuItem[#menuInforme1].onAction
	@FXML
	public void abrirInforme1(ActionEvent event) {
		ConexionDB cn = new ConexionDB();
		JasperReport report;
		try {
			report = (JasperReport) JRLoader.loadObject(getClass().getResource("/reports/Informe1.jasper"));
			JasperPrint jprint = JasperFillManager.fillReport(report, null, cn.getConexion());
			JasperViewer viewer = new JasperViewer(jprint, false);
			viewer.setVisible(true);
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	// Event Listener on MenuItem[#menuInforme2].onAction
	@FXML
	public void abrirInforme2(ActionEvent event) {
		ConexionDB cn = new ConexionDB();
		JasperReport report;
		try {
			report = (JasperReport) JRLoader.loadObject(getClass().getResource("/reports/Informe2.jasper"));
			JasperPrint jprint = JasperFillManager.fillReport(report, null, cn.getConexion());
			JasperViewer viewer = new JasperViewer(jprint, false);
			viewer.setVisible(true);
		} catch (JRException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Event Listener on MenuItem[#menuAyuda].onAction
	@FXML
	public void abrirAyuda(ActionEvent event) {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/VisorAyuda.fxml"));
		Parent root;
		try {
			root = loader.load();
			VisorAyudaController controller = loader.getController();
			Scene scene = new Scene(root);
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			Stage myStage =(Stage) this.btnAnterior.getScene().getWindow();
			stage.initOwner(myStage);
			stage.setScene(scene);
			stage.setTitle("Ayuda");
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	// Event Listener on MenuItem[#menuAyudaOnline].onAction
	@FXML
	public void abrirAyudaOnline(ActionEvent event) {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/VisorOnline.fxml"));
		Parent root;
		try {
			root = loader.load();
			VisorOnlineController controller = loader.getController();
			Scene scene = new Scene(root);
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			Stage myStage =(Stage) this.btnAnterior.getScene().getWindow();
			stage.initOwner(myStage);
			stage.setScene(scene);
			stage.setTitle("Ayuda Online");
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	// Event Listener on ListView[#lstTelefonos].onMouseClicked
	@FXML
	public void seleccionarTelefono(MouseEvent event) {
		if (lstTelefonos.getSelectionModel().getSelectedItem() != null) {
			btnBorrarTlf.setDisable(false);
			
			iLstTelefono = lstTelefonos.getSelectionModel().getSelectedIndex();
			t = lstTelefonos.getSelectionModel().getSelectedItem();
			
			
		}
	}

	// Event Listener on ListView[#lstEmails].onMouseClicked
	@FXML
	public void seleccionarEmail(MouseEvent event) {
		if (lstEmails.getSelectionModel().getSelectedItem() != null) {
			btnBorrarEmail.setDisable(false);
			
			iLstEmail = lstEmails.getSelectionModel().getSelectedIndex();
			e = lstEmails.getSelectionModel().getSelectedItem();
			
		
		}
	}

	// Event Listener on Button[#btnNuevoTlf].onAction
	@FXML
	public void crearTlf(ActionEvent event) {
		TextInputDialog dialog = new TextInputDialog("");
		dialog.setTitle("Nuevo Telefono");
		dialog.setHeaderText(null);
		dialog.setContentText("Escibe un numero de telefono:");
		Optional<String> dato = dialog.showAndWait();
		String nuevoTlf = "aaaaaaaaa";
		if (dato.isPresent()) {
			nuevoTlf=dato.get();
		}
		
		while (nuevoTlf.length() != 9 || cTelefono.existeTelefono(p.getDni(), nuevoTlf)) {
			Alert alert= new Alert(Alert.AlertType.INFORMATION);
			alert.initOwner(this.btnAnterior.getScene().getWindow());
			alert.setHeaderText(null);
			alert.setTitle("ERROR");
			alert.setContentText("El numero de telefono esta mal formado o esta repetido");
			alert.showAndWait();
			
			
			dialog = new TextInputDialog("");
			dialog.setTitle("Nuevo Telefono");
			dialog.setHeaderText(null);
			dialog.setContentText("Escibe un numero de telefono:");
			dato = dialog.showAndWait();
			if (dato.isPresent()) {
				nuevoTlf=dato.get();
			}
		}
		
		try {
			if (nuevoTlf != "aaaaaaaaa") {
				cTelefono.insertTelefono(new Telefono(0,p.getDni(), nuevoTlf));
				
				Alert alert= new Alert(Alert.AlertType.INFORMATION);
				alert.initOwner(this.btnAnterior.getScene().getWindow());
				alert.setHeaderText(null);
				alert.setTitle("EXITO");
				alert.setContentText("Telefono creado correctamente");
				alert.showAndWait();
				
				cargarTelefonos();
			}
			
		} catch (SQLException e) {
			Alert alert= new Alert(Alert.AlertType.INFORMATION);
			alert.initOwner(this.btnAnterior.getScene().getWindow());
			alert.setHeaderText(null);
			alert.setTitle("ERROR");
			alert.setContentText("No se ha podido crear el telefono");
			alert.showAndWait();
		}
		
	}

	// Event Listener on Button[#btnBorrarTlf].onAction
	@FXML
	public void borrarTlf(ActionEvent event) {
		try {
			cTelefono.deleteTelefono(t);
			
			btnBorrarTlf.setDisable(true);
			cargarTelefonos();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Event Listener on Button[#btnNuevoEmail].onAction
	@FXML
	public void crearEmail(ActionEvent event) {
		TextInputDialog dialog = new TextInputDialog("");
		dialog.setTitle("Nuevo Email");
		dialog.setHeaderText(null);
		dialog.setContentText("Escibe un Email");
		Optional<String> dato = dialog.showAndWait();
		String nuevoEmail = "@";
		if (dato.isPresent()) {
			nuevoEmail=dato.get();
		}
		
		while (!nuevoEmail.contains("@") || cEmail.existeEmail(p.getDni(), nuevoEmail)) {
			Alert alert= new Alert(Alert.AlertType.INFORMATION);
			alert.initOwner(this.btnAnterior.getScene().getWindow());
			alert.setHeaderText(null);
			alert.setTitle("ERROR");
			alert.setContentText("El email esta mal formado o esta repetido");
			alert.showAndWait();
			
			
			dialog = new TextInputDialog("");
			dialog.setTitle("Nuevo Email");
			dialog.setHeaderText(null);
			dialog.setContentText("Escibe un Email:");
			dato = dialog.showAndWait();
			if (dato.isPresent()) {
				nuevoEmail=dato.get();
			}
		}
		
		try {
			
			if (nuevoEmail != "@") {
				cEmail.insertEmail(new Email(0,p.getDni(), nuevoEmail));
				
				Alert alert= new Alert(Alert.AlertType.INFORMATION);
				alert.initOwner(this.btnAnterior.getScene().getWindow());
				alert.setHeaderText(null);
				alert.setTitle("EXITO");
				alert.setContentText("Email creado correctamente");
				alert.showAndWait();
				
				cargarTelefonos();
			}
			
		} catch (SQLException e) {
			Alert alert= new Alert(Alert.AlertType.INFORMATION);
			alert.initOwner(this.btnAnterior.getScene().getWindow());
			alert.setHeaderText(null);
			alert.setTitle("ERROR");
			alert.setContentText("No se ha podido crear el Email");
			alert.showAndWait();
		}
	}

	// Event Listener on Button[#btnBorrarEmail].onAction
	@FXML
	public void borrarEmail(ActionEvent event) {
		try {
			cEmail.deleteEmail(e);
			btnBorrarEmail.setDisable(true);
			
			cargarEmail();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Event Listener on Button[#btnAnterior].onAction
	@FXML
	public void anteriorPersona(ActionEvent event) {
		if ((iPersonas + 1) == lenPersonas) {
			btnAnterior.setDisable(false);
		}

		iPersonas--;

		if (iPersonas == 0) {
			btnSiguiente.setDisable(true);
		}
		cargarPersonas();
		cargarEmail();
		cargarTelefonos();

	}

	// Event Listener on Button[#btnSiguiente].onAction
	@FXML
	public void siguientePersona(ActionEvent event) {
		if (iPersonas == 0) {
			btnAnterior.setDisable(false);
		}

		iPersonas++;

		if ((iPersonas + 1) == lenPersonas) {
			btnSiguiente.setDisable(true);
		}
		cargarPersonas();
		cargarEmail();
		cargarTelefonos();

	}

	private void cargarPersonas() {
		cPersona = new PersonaDAO();

		arrPersonas = cPersona.selectPersonas();

		lenPersonas = arrPersonas.size();

		if (lenPersonas == 0) {

		} else {
			lblNumPersona.setText((iPersonas + 1) + " / " + lenPersonas);
			lblTitulo.setText(arrPersonas.get(iPersonas).toString());
			if (iPersonas == 0)
				btnAnterior.setDisable(true);
			p = arrPersonas.get(iPersonas);
		}
	}

	private void cargarEmail() {
		cEmail = new EmailDAO();

		dataEmail = FXCollections.observableArrayList();
		lstEmails.setItems(dataEmail);

		btnBorrarEmail.setDisable(true);

		ArrayList<Email> listaEmail = cEmail.selectEmail(p.getDni());
		dataEmail.addAll(listaEmail);
	}

	private void cargarTelefonos() {
		cTelefono = new TelefonoDAO();

		dataTelefono = FXCollections.observableArrayList();
		lstTelefonos.setItems(dataTelefono);

		btnBorrarTlf.setDisable(true);

		ArrayList<Telefono> listaTelefono = cTelefono.selectTelefonos(p.getDni());
		dataTelefono.addAll(listaTelefono);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cargarPersonas();
		cargarEmail();
		cargarTelefonos();

	}

}
