package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import config.ConexionDB;
import model.Email;

public class EmailDAO {
private ConexionDB cn;
	
	public EmailDAO () {
		cn = new ConexionDB();
	}
	
	public ArrayList<Email> selectEmail (String dni){
		PreparedStatement ps;
		ArrayList<Email> lstEmail= new ArrayList<Email>();
		
		try {
			ps = cn.getConexion().prepareStatement("select id, dni, email from email where dni = ?");
			ps.setString(1, dni);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				lstEmail.add(new Email(rs.getInt(1), rs.getString(2), rs.getString(3)));
				
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return lstEmail;
	}
	
	public boolean existeEmail (String dni, String email) {
		PreparedStatement ps;
		
		try {
			ps= cn.getConexion().prepareStatement("select email from email where dni = ? and email = ?");
			ps.setString(1, dni);
			ps.setString(2, email);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			return true;
		}
		return false;
	
	}
	
	public void insertEmail (Email email) throws SQLException {
		PreparedStatement ps;
		
		ps = cn.getConexion().prepareStatement("insert into email (dni, email) values (?,?)");
		ps.setString(1, email.getDni());
		ps.setString(2, email.getEmail());
		ps.executeUpdate();
		
	}
	
	public void deleteEmail (Email email) throws SQLException {
		PreparedStatement ps;
		
		ps=cn.getConexion().prepareStatement("delete from email where id = ?");
		ps.setInt(1, email.getId());
		
		ps.executeUpdate();
	}
}
