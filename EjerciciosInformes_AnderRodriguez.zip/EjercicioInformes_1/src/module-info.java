module EjercicioInformes_1 {
	requires javafx.controls;
	requires jasperreports;
	requires java.sql;
	
	opens application to javafx.graphics, javafx.fxml;
}
