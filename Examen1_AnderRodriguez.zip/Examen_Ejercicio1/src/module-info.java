module Examen_Ejercicio1 {
	requires java.desktop;
	requires java.sql;
}