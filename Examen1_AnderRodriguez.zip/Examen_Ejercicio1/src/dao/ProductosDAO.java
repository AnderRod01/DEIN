package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import config.ConexionDB;
import modelo.Producto;

public class ProductosDAO {
	private ConexionDB cn;
	
	public ProductosDAO () {
		cn = new ConexionDB();
	}
	
	public ArrayList<Producto> selectProductos(){
		PreparedStatement ps;
		ArrayList <Producto> lstProductos = new ArrayList <Producto>();
		try {
			ps=cn.getConexion().prepareStatement("select * from productos");
			ResultSet rs= ps.executeQuery();
			while (rs.next()) {
				lstProductos.add(new Producto(rs.getString(1), rs.getString(2), rs.getFloat(3), rs.getInt(4)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstProductos;
	}
	
	public boolean existeProducto (String codigo) {
		PreparedStatement ps;
		ArrayList <Producto> lstProductos = new ArrayList <Producto>();
		try {
			ps=cn.getConexion().prepareStatement("select * from productos where codigo = ?");
			ps.setString(1, codigo);
			ResultSet rs= ps.executeQuery();
			while (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			;
		}
		return false;
	}
	
	public void insertProducto (Producto p) {
		PreparedStatement ps;
		try {
			ps=cn.getConexion().prepareStatement("insert into productos (codigo, nombre, precio, disponible) values (?,?,?,?)");
			ps.setString(1, p.getCodigo());
			ps.setString(2, p.getNombre());
			ps.setFloat(3, p.getPrecio());
			ps.setInt(4, p.getDisponible());
			ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<Producto> selectFiltroProductos(String p){
		PreparedStatement ps;
		ArrayList <Producto> lstProductos = new ArrayList <Producto>();
		try {
			ps=cn.getConexion().prepareStatement("select * from productos where nombre like '%" + p + "%' or precio like '%" + p + "%' or codigo like '%" + p + "%'");
			ResultSet rs= ps.executeQuery();
			while (rs.next()) {
				lstProductos.add(new Producto(rs.getString(1), rs.getString(2), rs.getFloat(3), rs.getInt(4)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lstProductos;
	}
	
	public void updateProducto (Producto p) {
		PreparedStatement ps;
		
		try {
			ps= cn.getConexion().prepareStatement("update productos set nombre = ?, precio = ?, disponible = ? where codigo = ?");
			ps.setString(1, p.getNombre());
			ps.setFloat(2, p.getPrecio());
			ps.setInt(3, p.getDisponible());
			ps.setString(4, p.getCodigo());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean deleteProducto (String codigo) {
		PreparedStatement ps;
		try {
			ps=cn.getConexion().prepareStatement("delete from productos where codigo = ?");
			ps.setString(1, codigo);
			ps.executeUpdate();
		} catch (SQLException e) {
			return false;
		}
		return true;
	}
	
	public void cerrarConexion () {
		cn.cerrarConexion();
	}
	
	
}
