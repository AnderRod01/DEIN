package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.border.TitledBorder;
import javax.swing.border.BevelBorder;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.FlowLayout;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import dao.ProductosDAO;
import modelo.Producto;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JMenuItem;

public class Indice extends JFrame {

	private JPanel contentPane;
	private JTextField txtCodigo;
	private JTextField txtNombre;
	private JTextField txtPrecio;
	private JTextField txtFiltro;
	private JTable table;
	private ProductosDAO cProducto;
	private JButton btnCrear;
	private JCheckBox chckbxDisponible;
	private DefaultTableModel modelo;
	private JButton btnLimpiar;
	private JButton btnBuscar;
	private JPopupMenu popupMenu;
	private JMenuItem mntmBorrar;
	private JButton btnActualizar;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Indice frame = new Indice();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Indice() {
		cProducto =  new ProductosDAO();
		dibujar();
		gestionarEventos();
		
	}

	private void dibujar() {
		setTitle("GESTIONAR PRODUCTOS");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 476);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 153, 255));
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0};
		gbl_contentPane.rowHeights = new int[]{154, 63, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 1.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JPanel panel_Detalles = new JPanel();
		panel_Detalles.setBackground(new Color(0, 153, 255));
		panel_Detalles.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Detalles del producto", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(51, 51, 51)));
		GridBagConstraints gbc_panel_Detalles = new GridBagConstraints();
		gbc_panel_Detalles.insets = new Insets(0, 0, 5, 0);
		gbc_panel_Detalles.fill = GridBagConstraints.BOTH;
		gbc_panel_Detalles.gridx = 0;
		gbc_panel_Detalles.gridy = 0;
		contentPane.add(panel_Detalles, gbc_panel_Detalles);
		GridBagLayout gbl_panel_Detalles = new GridBagLayout();
		gbl_panel_Detalles.columnWidths = new int[]{0, 122, 0, 0, 0};
		gbl_panel_Detalles.rowHeights = new int[]{31, 33, 0, 0, 0};
		gbl_panel_Detalles.columnWeights = new double[]{0.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_Detalles.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0};
		panel_Detalles.setLayout(gbl_panel_Detalles);
		
		JLabel lblCdigo = new JLabel("Código:");
		GridBagConstraints gbc_lblCdigo = new GridBagConstraints();
		gbc_lblCdigo.anchor = GridBagConstraints.EAST;
		gbc_lblCdigo.insets = new Insets(0, 0, 5, 5);
		gbc_lblCdigo.gridx = 0;
		gbc_lblCdigo.gridy = 0;
		panel_Detalles.add(lblCdigo, gbc_lblCdigo);
		
		txtCodigo = new JTextField();
		GridBagConstraints gbc_txtCodigo = new GridBagConstraints();
		gbc_txtCodigo.insets = new Insets(0, 0, 5, 5);
		gbc_txtCodigo.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtCodigo.gridx = 1;
		gbc_txtCodigo.gridy = 0;
		panel_Detalles.add(txtCodigo, gbc_txtCodigo);
		txtCodigo.setColumns(10);
		
		JLabel lblNombre = new JLabel("Nombre:");
		GridBagConstraints gbc_lblNombre = new GridBagConstraints();
		gbc_lblNombre.anchor = GridBagConstraints.EAST;
		gbc_lblNombre.insets = new Insets(0, 0, 5, 5);
		gbc_lblNombre.gridx = 0;
		gbc_lblNombre.gridy = 1;
		panel_Detalles.add(lblNombre, gbc_lblNombre);
		
		txtNombre = new JTextField();
		GridBagConstraints gbc_txtNombre = new GridBagConstraints();
		gbc_txtNombre.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtNombre.gridwidth = 3;
		gbc_txtNombre.insets = new Insets(0, 0, 5, 0);
		gbc_txtNombre.gridx = 1;
		gbc_txtNombre.gridy = 1;
		panel_Detalles.add(txtNombre, gbc_txtNombre);
		txtNombre.setColumns(10);
		
		JLabel lblPrecio = new JLabel("Precio:");
		GridBagConstraints gbc_lblPrecio = new GridBagConstraints();
		gbc_lblPrecio.anchor = GridBagConstraints.EAST;
		gbc_lblPrecio.insets = new Insets(0, 0, 5, 5);
		gbc_lblPrecio.gridx = 0;
		gbc_lblPrecio.gridy = 2;
		panel_Detalles.add(lblPrecio, gbc_lblPrecio);
		
		txtPrecio = new JTextField();
		GridBagConstraints gbc_txtPrecio = new GridBagConstraints();
		gbc_txtPrecio.insets = new Insets(0, 0, 5, 5);
		gbc_txtPrecio.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtPrecio.gridx = 1;
		gbc_txtPrecio.gridy = 2;
		panel_Detalles.add(txtPrecio, gbc_txtPrecio);
		txtPrecio.setColumns(10);
		
		chckbxDisponible = new JCheckBox("Disponible");
		chckbxDisponible.setBackground(new Color(0, 153, 255));
		GridBagConstraints gbc_chckbxDisponible = new GridBagConstraints();
		gbc_chckbxDisponible.insets = new Insets(0, 0, 5, 5);
		gbc_chckbxDisponible.gridx = 1;
		gbc_chckbxDisponible.gridy = 3;
		panel_Detalles.add(chckbxDisponible, gbc_chckbxDisponible);
		
		JPanel panel_Botones = new JPanel();
		panel_Botones.setBackground(new Color(0, 153, 255));
		FlowLayout fl_panel_Botones = (FlowLayout) panel_Botones.getLayout();
		fl_panel_Botones.setHgap(8);
		GridBagConstraints gbc_panel_Botones = new GridBagConstraints();
		gbc_panel_Botones.gridwidth = 2;
		gbc_panel_Botones.insets = new Insets(0, 0, 0, 5);
		gbc_panel_Botones.fill = GridBagConstraints.BOTH;
		gbc_panel_Botones.gridx = 1;
		gbc_panel_Botones.gridy = 4;
		panel_Detalles.add(panel_Botones, gbc_panel_Botones);
		
		btnCrear = new JButton("Crear");
		
		panel_Botones.add(btnCrear);
		
		btnActualizar = new JButton("Actualizar");
		panel_Botones.add(btnActualizar);
		btnActualizar.setEnabled(false);
		
		btnLimpiar = new JButton("Limpiar");
		
		panel_Botones.add(btnLimpiar);
		
		JPanel panel_Filtro = new JPanel();
		panel_Filtro.setBackground(new Color(0, 153, 255));
		GridBagConstraints gbc_panel_Filtro = new GridBagConstraints();
		gbc_panel_Filtro.insets = new Insets(0, 0, 5, 0);
		gbc_panel_Filtro.fill = GridBagConstraints.BOTH;
		gbc_panel_Filtro.gridx = 0;
		gbc_panel_Filtro.gridy = 1;
		contentPane.add(panel_Filtro, gbc_panel_Filtro);
		GridBagLayout gbl_panel_Filtro = new GridBagLayout();
		gbl_panel_Filtro.columnWidths = new int[]{0, 0, 0, 0};
		gbl_panel_Filtro.rowHeights = new int[]{0, 0};
		gbl_panel_Filtro.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_panel_Filtro.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_Filtro.setLayout(gbl_panel_Filtro);
		
		JLabel lblFiltro = new JLabel("Filtro:");
		GridBagConstraints gbc_lblFiltro = new GridBagConstraints();
		gbc_lblFiltro.insets = new Insets(0, 0, 0, 5);
		gbc_lblFiltro.anchor = GridBagConstraints.EAST;
		gbc_lblFiltro.gridx = 0;
		gbc_lblFiltro.gridy = 0;
		panel_Filtro.add(lblFiltro, gbc_lblFiltro);
		
		txtFiltro = new JTextField();
		GridBagConstraints gbc_txtFiltro = new GridBagConstraints();
		gbc_txtFiltro.insets = new Insets(0, 0, 0, 5);
		gbc_txtFiltro.fill = GridBagConstraints.HORIZONTAL;
		gbc_txtFiltro.gridx = 1;
		gbc_txtFiltro.gridy = 0;
		panel_Filtro.add(txtFiltro, gbc_txtFiltro);
		txtFiltro.setColumns(10);
		
		btnBuscar = new JButton("Buscar");
		GridBagConstraints gbc_btnBuscar = new GridBagConstraints();
		gbc_btnBuscar.gridx = 2;
		gbc_btnBuscar.gridy = 0;
		panel_Filtro.add(btnBuscar, gbc_btnBuscar);
		
		table = new JTable();
		cargarTabla();
		
		popupMenu = new JPopupMenu();
		addPopup(table, popupMenu);
		
		mntmBorrar = new JMenuItem("Borrar");
		
		popupMenu.add(mntmBorrar);
		GridBagConstraints gbc_table = new GridBagConstraints();
		gbc_table.fill = GridBagConstraints.BOTH;
		gbc_table.gridx = 0;
		gbc_table.gridy = 2;
		contentPane.add(table, gbc_table);
	}

	private void gestionarEventos() {
		btnCrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int disp = 0;
				if (chckbxDisponible.isSelected()) {
					disp = 1;
				}
				else {
					disp = 0;
				}
				
				if (datosCorrectos()) {
					
					if (!cProducto.existeProducto(txtCodigo.getText())) {
						Float precio = (float) (Math.round(Float.parseFloat(txtPrecio.getText())*100.0)/100.0);
						Producto p =  new Producto (txtCodigo.getText(), txtNombre.getText(), precio,disp);
						
						cProducto.insertProducto(p);
						JOptionPane.showMessageDialog(getContentPane(), "Datos añadidos correctamente");
						cargarTabla();
						limpiarDatos();
					}else {
						JOptionPane.showMessageDialog(getContentPane(), "No se han podido añadir los datos: Producto existente");
					}
					
				}
				else {
					JOptionPane.showMessageDialog(getContentPane(), "No se han podido añadir los datos");
				}
				
				
				
				
			}
		});
		
		btnBuscar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String filtro = txtFiltro.getText();
				
				cargarTabla(filtro);
				
			}
		});
		
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				limpiarDatos();
			}
		});
		
		mntmBorrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int row = table.getSelectedRow();
				if (row>0) {
					String message = "¿Estás seguro de que deseas borrar el campo?";
					int input = JOptionPane.showConfirmDialog(null, message, "WARNING", JOptionPane.YES_NO_OPTION);	
					if (input == JOptionPane.YES_OPTION) {
						String codigo = "";
						try {
							codigo = table.getModel().getValueAt(row, 0).toString();
						} catch (NumberFormatException e) {
						}
						
						cProducto.deleteProducto(codigo);
						cargarTabla();
						limpiarDatos();
					}
				}
				
			}
		});
		
		btnActualizar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				int disp = 0;
				if (chckbxDisponible.isSelected()) {
					disp = 1;
				}
				else {
					disp = 0;
				}
				
				if (datosCorrectos()) {
					
					
						Float precio = (float) (Math.round(Float.parseFloat(txtPrecio.getText())*100.0)/100.0);
						Producto p =  new Producto (txtCodigo.getText(), txtNombre.getText(), precio,disp);
						
						cProducto.updateProducto(p);
						JOptionPane.showMessageDialog(getContentPane(), "Datos actualizados correctamente");
						cargarTabla();
						limpiarDatos();
					
					
				}
				else {
					JOptionPane.showMessageDialog(getContentPane(), "No se han podido añadir los datos");
				}
				
			}
		});
		
		table.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (arg0.getClickCount() == 2) {
					
					modoEditar();
					
				}
				
			}
		});
	}
	
	private void modoEditar () {
		txtCodigo.setEnabled(false);
		btnCrear.setEnabled(false);
		btnActualizar.setEnabled(true);
		
		int row = table.getSelectedRow();
		txtCodigo.setText(table.getModel().getValueAt(row, 0).toString());
		txtNombre.setText(table.getModel().getValueAt(row, 1).toString());
		txtPrecio.setText(table.getModel().getValueAt(row, 2).toString());
		

		if (table.getModel().getValueAt(row, 3).toString().equalsIgnoreCase("si")) {
			chckbxDisponible.setSelected(true);
			
		}else {
			chckbxDisponible.setSelected(false);
		}
	}
	
	
	private boolean datosCorrectos () {
		if (txtCodigo.getText().length() != 5) {
			return false;
		}
		
		if (txtNombre.getText().isEmpty() || txtPrecio.getText().isEmpty() || txtCodigo.getText().isEmpty()) {
			return false;
		}
		try {
			Float precio = Float.parseFloat(txtPrecio.getText());
			return true;
		}
		catch(NumberFormatException nfe)
		{
		   return false;
		}
		
	}
	
	private void limpiarDatos () {
		
		txtCodigo.setEnabled(true);
		btnCrear.setEnabled(true);
		btnActualizar.setEnabled(false);
		txtNombre.setText("");
		txtCodigo.setText("");
		txtPrecio.setText("");
		txtFiltro.setText("");
		
		chckbxDisponible.setSelected(false);
	}
	
	private void cargarTabla () {
		modelo = new DefaultTableModel() {
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		table.setModel(modelo);
		String[] headers = new String[0];
		
		headers = Producto.campos();
		modelo.setColumnIdentifiers(headers);
		modelo.addRow(headers);
		ArrayList <Producto> productos = cProducto.selectProductos();
		for (Producto p: productos) {
			String []row  = p.getAll();
			modelo.addRow(row);
		}
		for (int i = 0; i < headers.length; i++) {
			table.getColumnModel().getColumn(i).setPreferredWidth(130);
		}
		
	}
	
	private void cargarTabla (String filtro) {
		modelo = new DefaultTableModel() {
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		table.setModel(modelo);
		String[] headers = new String[0];
		
		headers = Producto.campos();
		modelo.setColumnIdentifiers(headers);
		modelo.addRow(headers);
		ArrayList <Producto> productos = cProducto.selectFiltroProductos(filtro);
		for (Producto p: productos) {
			String []row  = p.getAll();
			modelo.addRow(row);
		}
		for (int i = 0; i < headers.length; i++) {
			table.getColumnModel().getColumn(i).setPreferredWidth(130);
		}
		
	}

	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
			
		});
	}
}
