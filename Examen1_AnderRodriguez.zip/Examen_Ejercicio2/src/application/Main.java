package application;
	
import java.util.Locale;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import config.Propiedades;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Locale locale = new Locale (Propiedades.getValor("language"),Propiedades.getValor("region"));
			ResourceBundle bundle = ResourceBundle.getBundle("config/messages", locale);
			TabPane root = (TabPane)FXMLLoader.load(getClass().getResource("/fxml/IndexFXML.fxml"), bundle);
			Scene scene = new Scene(root);
			primaryStage.setTitle(bundle.getString("window.title"));
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
