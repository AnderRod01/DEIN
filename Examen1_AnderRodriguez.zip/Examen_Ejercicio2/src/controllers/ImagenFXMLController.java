package controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import modelo.Ubicacion;

public class ImagenFXMLController{
	@FXML
	private ImageView imgGrande;

	private Ubicacion u;

	public void setUbicacion (Ubicacion ubi) {
		u = ubi;
		File f = new File ("./resources/" + u.getImagen());
		try {
			InputStream image = (InputStream) new FileInputStream(f);
			imgGrande.setImage(new Image(image));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	
	
}
