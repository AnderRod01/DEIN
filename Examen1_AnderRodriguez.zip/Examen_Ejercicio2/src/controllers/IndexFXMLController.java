package controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import dao.UbicacionDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import modelo.Ubicacion;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;

public class IndexFXMLController implements Initializable{
	@FXML
	private TableView <Ubicacion> tblUbicaciones;
	@FXML
	private TableColumn<Ubicacion, String> colSeccion;
	@FXML
	private TableColumn<Ubicacion, String> colUbicacion;
	@FXML
	private ImageView imgPasillo;
	
	private ObservableList<Ubicacion> data;
	private int iSeleccionado = -1;
	private UbicacionDAO cUbicacion;
	
	private Ubicacion u;

	// Event Listener on TableView[#tblUbicaciones].onMouseClicked
	@FXML
	public void mostrarImagen(MouseEvent event) {
		
		
		iSeleccionado = tblUbicaciones.getSelectionModel().getSelectedIndex();
		u = tblUbicaciones.getSelectionModel().getSelectedItem();
		if (iSeleccionado != -1) {
			File f = new File ("./resources/" + u.getImagen());
			try {
				InputStream image = (InputStream) new FileInputStream(f);
				imgPasillo.setImage(new Image(image));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}
	// Event Listener on ImageView[#imgPasillo].onMouseClicked
	@FXML
	public void abrirImagen(MouseEvent event) {
		u = tblUbicaciones.getSelectionModel().getSelectedItem();
		String titulo = u.getSeccion() + " - " + u.getUbicacion();
		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/ImagenFXML.fxml"));
		Parent root;

		try {
			root = loader.load();
			ImagenFXMLController controller = loader.getController();
			controller.setUbicacion(u);
			Scene scene = new Scene(root);
			Stage stage = new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			Stage myStage =(Stage) this.tblUbicaciones.getScene().getWindow();
			stage.initOwner(myStage);
			stage.setResizable(false);
			stage.setScene(scene);
			stage.setTitle(titulo);
			stage.showAndWait();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		
	}
		
	private void recogerDatos() {
		ArrayList <Ubicacion> ubicaciones = cUbicacion.selectUbicaciones();
		
		for (Ubicacion ubi: ubicaciones) {
			data.add(ubi);
		}
		
		tblUbicaciones.refresh();
	}
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		cUbicacion = new UbicacionDAO();
		data = FXCollections.observableArrayList();
		tblUbicaciones.setItems(data);
		colSeccion.setCellValueFactory(new PropertyValueFactory<Ubicacion, String>("Seccion"));
		colUbicacion.setCellValueFactory(new PropertyValueFactory<Ubicacion, String>("Ubicacion"));
		recogerDatos();
	}
	
}
