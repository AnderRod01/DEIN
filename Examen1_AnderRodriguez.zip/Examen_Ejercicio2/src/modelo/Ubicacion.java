package modelo;

public class Ubicacion {
	private int id_ubicacion;
	private String seccion, ubicacion, imagen;
	
	public Ubicacion(int id_ubicacion, String seccion, String ubicacion, String imagen) {
		this.id_ubicacion = id_ubicacion;
		this.seccion = seccion;
		this.ubicacion = ubicacion;
		this.imagen = imagen;
	}

	public int getId_ubicacion() {
		return id_ubicacion;
	}

	public String getSeccion() {
		return seccion;
	}

	public String getUbicacion() {
		return ubicacion;
	}

	public String getImagen() {
		return imagen;
	}
	
	
}
